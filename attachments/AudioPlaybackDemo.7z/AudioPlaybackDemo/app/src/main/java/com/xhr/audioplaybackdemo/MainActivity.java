package com.xhr.audioplaybackdemo;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.annotation.TargetApi;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.projection.MediaProjectionManager;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    public static final String TAG = "CALL_FUNCTION_TEST";

    private static final int ALL_PERMISSIONS_PERMISSION_CODE = 1000;
    private static final int CREATE_SCREEN_CAPTURE = 1001;

    private MediaProjectionManager _manager;

    private Button _btnInitCapture;
    private Button _btnStartCapture;
    private Button _btnStopCapture;
    private Button _btnGetOkPermissions;


    private String [] appPermissions = {
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.FOREGROUND_SERVICE
    };


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        _btnGetOkPermissions = findViewById(R.id.btnGetOkPermissions);
        _btnGetOkPermissions.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                checkAndRequestPermissions();
            }
        });

        _btnInitCapture = findViewById(R.id.btnInitCapture);
        _btnInitCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                initAudioCapture();
            }
        });

        _btnStartCapture = findViewById(R.id.btnStartCapture);
        _btnStartCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startRecording();
            }
        });

        _btnStopCapture = findViewById(R.id.btnStopAudioCapture);
        _btnStopCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                stopRecording();
            }
        });
    }



    @TargetApi(Build.VERSION_CODES.LOLLIPOP)
    private void initAudioCapture() {
        _manager = (MediaProjectionManager) getSystemService(MEDIA_PROJECTION_SERVICE);
        Intent intent = _manager.createScreenCaptureIntent();
        startActivityForResult(intent, CREATE_SCREEN_CAPTURE);
    }

    private void stopRecording() {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(MediaCaptureService.ACTION_ALL);
        broadCastIntent.putExtra(MediaCaptureService.EXTRA_ACTION_NAME, MediaCaptureService.ACTION_STOP);
        this.sendBroadcast(broadCastIntent);
    }

    private void startRecording() {
        Intent broadCastIntent = new Intent();
        broadCastIntent.setAction(MediaCaptureService.ACTION_ALL);
        broadCastIntent.putExtra(MediaCaptureService.EXTRA_ACTION_NAME, MediaCaptureService.ACTION_START);
        this.sendBroadcast(broadCastIntent);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent intent) {
        super.onActivityResult(requestCode, resultCode, intent);
        if (CREATE_SCREEN_CAPTURE == requestCode) {
            if (resultCode == RESULT_OK) {
                Intent i = new Intent(this, MediaCaptureService.class);
                i.setAction(MediaCaptureService.ACTION_START);
                i.putExtra(MediaCaptureService.EXTRA_RESULT_CODE, resultCode);
                i.putExtras(intent);
                this.startService(i);
            } else {
                // user did not grant permissions
            }
        }
    }


    public boolean checkAndRequestPermissions(){
        List< String > listPermissionsNeeded = new ArrayList<>();
        for(String permission : appPermissions){
            if(ContextCompat.checkSelfPermission(this, permission) != PackageManager.PERMISSION_GRANTED){
                listPermissionsNeeded.add(permission);
            }
        }

        if(!listPermissionsNeeded.isEmpty()){
            ActivityCompat.requestPermissions(this, listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), ALL_PERMISSIONS_PERMISSION_CODE);
            return false;
        }

        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == ALL_PERMISSIONS_PERMISSION_CODE){
            HashMap< String, Integer > permissionResults = new HashMap<>();
            int deniedCount = 0;
            for(int permissionIndx = 0; permissionIndx < permissions.length; permissionIndx++){
                if(grantResults[permissionIndx] != PackageManager.PERMISSION_GRANTED){
                    permissionResults.put(permissions[permissionIndx], grantResults[permissionIndx]);
                    deniedCount++;
                }
            }
            if(deniedCount == 0){

            } else {

                Log.e(TAG,"Permission Denied!  Now you must allow  permission from settings.");


            }
        }
    }

}
